package com.example.DependencyInjectionCode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DependencyInjectionCodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DependencyInjectionCodeApplication.class, args);
	}

}
