package com.example.sreenath.introToSpringBoot.IntroToSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntroToSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(IntroToSpringBootApplication.class, args);
	}

}
