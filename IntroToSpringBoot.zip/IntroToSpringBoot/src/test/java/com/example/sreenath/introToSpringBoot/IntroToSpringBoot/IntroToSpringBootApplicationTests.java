package com.example.sreenath.introToSpringBoot.IntroToSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntroToSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
